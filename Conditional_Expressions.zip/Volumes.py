__name__ = 'B. Joel'

'''
Volumes
Friday, March 31, 2023
Calculates volume of rectangular prism, sphere, and cube based off user inputs
'''

import math

length = float(input('Enter the length of the rectangular prism: '))
width = float(input('Enter the width of the rectangular prism: '))
height = float(input('Enter the height of the rectangular prism: '))

volume = length*width*height
print('The volume is:', "{:.2f}".format(volume), 'units cubed')

radius = float(input('Enter the radius of the sphere: '))
volume = math.pi*(2*radius)**3/6
print('The volume is:', "{:.2f}".format(volume), 'units cubed')

side = float(input('Enter side length of the cube: '))
volume = side**3
print('The volume is:', "{:.2f}".format(volume), 'units cubed')
